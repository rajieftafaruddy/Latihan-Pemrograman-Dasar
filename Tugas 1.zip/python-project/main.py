angka1 = float(input("Masukkan angka pertama: "))
angka2 = float(input("Masukkan angka kedua: "))

if angka1 > angka2:
    maksimal = angka1
elif angka2 > angka1:
    maksimal = angka2
else:
    maksimal = None

if maksimal is not None:
    print(f"Angka maksimal dari {angka1} dan {angka2} adalah: {maksimal}")
else:
    print("Kedua angka bernilai sama.")
